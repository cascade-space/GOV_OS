﻿# GovOS — User Journey Documentation
## MASTER INDEX + PROJECT User Philosophy

**Reference Municipality:** Hubballi-Dharwad Municipal Corporation (HDMC), Karnataka
**Constituency:** Dharwad #71 | MLA: Amrut Desai
**Wards:** Saptapur, Kalyan Nagar, Line Bazaar, Gandhinagar, Kelgeri, Hosayellapur, Navalur, Sadhankeri

---

## DOCUMENT INDEX

| File | Persona | Key Workflows |
|------|---------|---------------|
| 01_Citizen_Unauthenticated.md | Citizen (no account) | Submit complaint, track status |
| 02_Citizen_Registered.md | Citizen (OTP login) | Dashboard, rating, reopen |
| 03_Field_Officer.md | Field Officer | Receive tasks, execute, upload evidence |
| 04_Department_Head.md | Department Head | Verify work, manage officers, analytics |
| 05_MLA_Representative.md | MLA / Elected Rep | Monitor constituency, issue directives |
| 06_Tenant_Admin.md | Tenant Admin (Municipality) | Full governance management |
| 07_Super_Admin.md | GovOS Super Admin | Platform operations, multi-tenant |
| 08_Complaint_Lifecycle_Thread.md | All Roles | End-to-end complaint lifecycle |
| 09_Codebase_Mind_Map.md | Dev Reference | Domain-to-file-to-layer map |

---

## PROJECT USER PHILOSOPHY

### The Core Belief
GovOS is built on a single philosophical conviction:

  "Governance accountability is only possible when every action is visible,
   every complaint is traceable, and every resolution is verifiable."

This philosophy shapes how users interact with the system:

### 1. The Citizen is the Source of Truth
- Citizens don't need accounts to file complaints — removing friction maximizes participation
- The complaint number (CMP-HDMC-202609-0024) is the citizen's receipt — immutable proof they were heard
- Citizens get the final word on whether their complaint is truly resolved (72h confirmation window)
- If a citizen says "no, this is NOT fixed" — the system forces a rework cycle

### 2. The Officer is Accountable, Not Just Assigned
- Officers cannot self-verify their own work (separation of duties enforced in code)
- GPS distance deviation is calculated — an officer cannot claim to have fixed something
  500 meters from the actual complaint site
- Every action (start, complete, rework) is timestamped and immutable in audit_logs
- SLA breach is not punitive — it is a signal for institutional support and escalation

### 3. The Admin is the Operational Governor
- Admins do not do the work — they enable, verify, and oversee
- Assignment is a deliberate act (not just automatic AI routing) — admin owns allocation
- Verification is a formal QC step — admin explicitly signs off on resolutions
- If verification fails twice, the system auto-escalates to Department Head

### 4. The MLA is the Democratic Override
- Any complaint can be elevated to a political directive by an MLA
- Directives are binding — they signal constituency-level urgency
- MLA visibility into complaint data is read-only governance — not operational interference
- The system provides the MLA with data, not power to close/reopen (that remains with Admin)

### 5. The Super Admin is the Platform Steward
- Super Admin is Prajna Labs / Cascade Technologies — the platform operator
- Super Admin can see across ALL tenants (HDMC, Mumbai, Bengaluru, etc.)
- Multi-tenant isolation means no municipality's data leaks to another
- Super Admin provisions municipalities — they do not operate them

---

## COMPLAINT NUMBER ANATOMY

  CMP - HDMC - 202609 - 0024
   |     |       |        |
   |     |       |        +--- Sequential number within tenant+month
   |     |       +------------ Year + Month (YYYYMM)
   |     +-------------------- Tenant code (HDMC = Hubballi-Dharwad Municipal Corp)
   +--------------------------- Fixed prefix "CMP" for Complaint

---

## THE SLA FRAMEWORK (Dharwad Config)

| Priority | SLA Window | Who Sets It | Example |
|----------|-----------|-------------|---------|
| CRITICAL | 12 hours | AI (physical danger) | Open manhole, live wire |
| HIGH | 24 hours | AI (area-wide impact) | Pipeline burst |
| MEDIUM | 48 hours | AI (standard) | Broken streetlight |
| LOW | 72 hours | AI (minor) | Paint on road |

At 75% of window -> Warning event fired -> Officer notified
At 100% of window -> SLA breach -> Escalation Level 1 -> Admin + Dept Head alerted
At 24h past breach (L1 unresolved) -> Escalation Level 2 -> Priority bumped to CRITICAL -> MLA/Executive alerted
At 72h post-RESOLVED (no citizen contest) -> Auto-close

---

## ROLE PERMISSION MATRIX

| Action | Citizen | Officer | Dept Head | Admin | MLA | SuperAdmin |
|--------|---------|---------|-----------|-------|-----|-----------|
| Submit complaint (public) | YES | YES | YES | YES | YES | YES |
| Track by complaint number | YES | YES | YES | YES | YES | YES |
| Login (OTP) | YES | YES | YES | YES | YES | YES |
| View assigned tasks | - | OWN | DEPT | TENANT | - | ALL |
| Start work on complaint | - | YES | YES | YES | - | YES |
| Complete work + evidence | - | YES | YES | YES | - | YES |
| Assign complaint to officer | - | - | YES | YES | - | YES |
| Verify resolved complaint | - | - | YES* | YES | - | YES |
| Request rework | - | - | YES | YES | - | YES |
| Issue MLA directive | - | - | - | YES | YES | YES |
| View analytics dashboard | - | - | DEPT | TENANT | CONST | ALL |
| Manage officers | - | - | DEPT | TENANT | - | ALL |
| Manage departments | - | - | - | TENANT | - | YES |
| Manage tenants | - | - | - | - | - | YES |
| View audit logs | - | - | - | TENANT | - | ALL |

*YES* = Cannot verify OWN assigned complaint (separation of duties)
